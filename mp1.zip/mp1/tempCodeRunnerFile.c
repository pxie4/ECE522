
    // shuffle(strides, size);