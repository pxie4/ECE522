#!/bin/bash


sudo cat /sys/kernel/debug/extfrag/unusable_index
